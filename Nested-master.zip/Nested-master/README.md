# Nested

jQuery Nested plugin for a gap free, multi column grid layout experience.
<br>Demo: [http://suprb.com/apps/nested/](http://suprb.com/apps/nested/)

#### Contributor

[Jonas Blomdin](http://github.com/jonasblomdin/)

#### Compare the result

Nested to the left and Grid-A-Licious/Masonry to the right.

!["compare"](https://dl.dropbox.com/u/35476/compare.jpg)

